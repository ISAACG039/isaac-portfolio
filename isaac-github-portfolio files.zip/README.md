# Isaac Contreras Portfolio

A responsive personal portfolio website built with HTML, CSS, and JavaScript.

## Sections

- About Me
- Skills
- Projects
- Professional Experience
- Certifications
- Contact Information

## Publish with GitHub Pages

1. Create a public GitHub repository named `portfolio`.
2. Upload `index.html`, `style.css`, and `script.js`.
3. Open **Settings** → **Pages**.
4. Choose **Deploy from a branch**.
5. Select the `main` branch and `/root`.
6. Save.

Your site will appear at:

`https://issacg039.github.io/portfolio/`

## Customize

- Add your LinkedIn link inside `index.html`.
- Add a resume PDF and link it from the navigation or hero section.
- Replace the initials card with a professional headshot if desired.
